# Shared-storage based death #

A highly reliable fencing or Shoot-the-other-node-in-the-head (STONITH) mechanism that works by utilizing shared storage.

The component works with Pacemaker clusters, and is currently known to
compile and function on Pacemaker 1.1.7+ and corosync 1.4.x or 2.3.x.

Please see https://github.com/l-mb/sbd/blob/master/man/sbd.8.pod for the full documentation.

